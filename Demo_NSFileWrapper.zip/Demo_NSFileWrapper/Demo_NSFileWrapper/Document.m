//
//  Document.m
//  Demo_NSFileWrapper
//
//  Created by Next on 7/20/17.
//  Copyright © 2017 Next. All rights reserved.
//

#if DEBUG == 0
#define DEBUGLOG (...)
#elif DEBUG == 1
#define DEBUGLOG (...)NSLOG(__VA_ARGS__)
#endif

#import "Document.h"

@interface Document ()

@end

@implementation Document

- (instancetype)init {
    self = [super init];
    if (self) {
		// Add your subclass-specific initialization here.
    }
    return self;
}

+ (BOOL)autosavesInPlace {
	return YES;
}


- (void)makeWindowControllers {
	// Override to return the Storyboard file name of the document.
	[self addWindowController:[[NSStoryboard storyboardWithName:@"Main" bundle:nil] instantiateControllerWithIdentifier:@"Document Window Controller"]];
}


- (NSData *)dataOfType:(NSString *)typeName error:(NSError **)outError {
	// Insert code here to write your document to data of the specified type. If outError != NULL, ensure that you create and set an appropriate error when returning nil.
	// You can also choose to override -fileWrapperOfType:error:, -writeToURL:ofType:error:, or -writeToURL:ofType:forSaveOperation:originalContentsURL:error: instead.
	[NSException raise:@"UnimplementedMethod" format:@"%@ is unimplemented", NSStringFromSelector(_cmd)];
	
	return nil;
}


- (BOOL)readFromData:(NSData *)data ofType:(NSString *)typeName error:(NSError **)outError {
	// Insert code here to read your document from the given data of the specified type. If outError != NULL, ensure that you create and set an appropriate error when returning NO.
	// You can also choose to override -readFromFileWrapper:ofType:error: or -readFromURL:ofType:error: instead.
	// If you override either of these, you should also override -isEntireFileLoaded to return NO if the contents are lazily loaded.
	[NSException raise:@"UnimplementedMethod" format:@"%@ is unimplemented", NSStringFromSelector(_cmd)];
	return YES;
}

- (NSFileWrapper*) fileWrapperOfType:(NSString *)typeName error:(NSError *__autoreleasing *)outError {
	
	NSFileWrapper *removedFile = [self.documentFileWrapper.fileWrappers objectForKey:@"test.rtf"];
	[self.documentFileWrapper removeFileWrapper:removedFile];
	
	NSFileWrapper *newFile = [[NSFileWrapper alloc] initRegularFileWithContents:[@"File was changed" dataUsingEncoding:NSUTF8StringEncoding]];
	newFile.preferredFilename = self.documentFileWrapper.filename;

	[self.documentFileWrapper addFileWrapper:newFile];

	return self.documentFileWrapper;
}

- (BOOL) readFromFileWrapper:(NSFileWrapper *)fileWrapper ofType:(NSString *)typeName error:(NSError *__autoreleasing *)outError {
	self.documentFileWrapper = fileWrapper;
	NSString *string1 = [[NSString alloc] initWithData:self.documentFileWrapper.regularFileContents encoding:NSUTF8StringEncoding];
	NSLog(@"%@",string1);
	return YES;
}

- (void) addFileToDocumentFromURL:(NSURL*)fileURL {
	NSData* fileData = [NSData dataWithContentsOfURL:fileURL];
	NSFileWrapper *fileWrapper = [[NSFileWrapper alloc] initRegularFileWithContents:fileData];
	fileWrapper.preferredFilename = [fileURL lastPathComponent];
	[self.documentFileWrapper addFileWrapper:fileWrapper];
	[self updateChangeCount:NSChangeDone];
}

- (void) removeFileFromDocumentWithName:(NSString*)name {
	NSFileWrapper *fileWrapper = [self.documentFileWrapper.fileWrappers objectForKey:name];
	if (fileWrapper) {
		[self.documentFileWrapper removeFileWrapper:fileWrapper];
		[self updateChangeCount:NSChangeDone];
	}
}

- (NSFileWrapper*) documentFileWrapper {
	NSMutableDictionary* wrappers = [NSMutableDictionary dictionary];
	if (!_documentFileWrapper) { // New document
		_documentFileWrapper = [[NSFileWrapper alloc] initDirectoryWithFileWrappers:wrappers];
	}
	return _documentFileWrapper;
}
@end
