//
//  main.m
//  Demo_NSFileWrapper
//
//  Created by Next on 7/20/17.
//  Copyright © 2017 Next. All rights reserved.
//

#import <Cocoa/Cocoa.h>

int main(int argc, const char * argv[]) {
	return NSApplicationMain(argc, argv);
}
