//
//  Document.h
//  Demo_NSFileWrapper
//
//  Created by Next on 7/20/17.
//  Copyright © 2017 Next. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface Document : NSDocument

// Top-level document wrapper
@property (nonatomic,strong) NSFileWrapper* documentFileWrapper;

- (void) removeFileFromDocumentWithName:(NSString*)name;
- (void) addFileToDocumentFromURL:(NSURL*)fileURL ;

- (NSFileWrapper*) documentFileWrapper;

@end

