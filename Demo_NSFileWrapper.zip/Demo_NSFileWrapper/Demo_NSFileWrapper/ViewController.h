//
//  ViewController.h
//  Demo_NSFileWrapper
//
//  Created by Next on 7/20/17.
//  Copyright © 2017 Next. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface ViewController : NSViewController


@end

